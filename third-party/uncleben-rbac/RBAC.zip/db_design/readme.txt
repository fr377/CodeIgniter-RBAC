The database was desinged with dbWrench (www.dbwrench.com). You will need it to open the rbac.xml file.
