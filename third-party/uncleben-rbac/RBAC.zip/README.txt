The folder 'db' must have write permission

Run the rbac.sql file in the db_design folder to create the database.

You need to install the ADODB database connection layer from http://adodb.sourceforge.net/
Change the paramaters in the config.php file to match your setup.
As well as the db_connection.php file

Run the setup.php file first and then the example.php file for some examples on how to use the system.
