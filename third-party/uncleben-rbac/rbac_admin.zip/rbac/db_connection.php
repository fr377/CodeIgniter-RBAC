<?php
$_host = 'localhost';
$_user = 'root';
$_pswd = '';
$db_name = 'rbac_test';
