<?php

include 'config.php';
include_once 'class.page_bv.php';


$_page = & new Page_bv();

$_page->PrintPage('Hello there');


?>
