<?php

define('DEBUG', TRUE);
define('LOG_ERROR_FILE', '/var/www/error.log');
define('ADMIN_EMAIL', 'vhd@vhd.com.au');
define('DOMAIN', 'http://localhost/');

define('CLASSES_DIR', '/var/www/classes/');

define('ADODB_INC', '/var/www/adodb/adodb.inc.php');
define('DB_CON_FILE', '/var/www/classes/page/db_connection.php');

define('CSS_DIR', 'http://localhost/classes/form/css/');


?>
