<a href="users_view.php">users</a><br>
<a href="rbac_roles_view.php">roles</a><br>
<a href="rbac_users_has_roles_view.php">users has roles</a><br>
<a href="rbac_roles_has_domain_privileges_view.php">roles permissions</a><br>
<br>
<b>Privileges</b><br>
<a href="rbac_privileges_view.php">privileges</a><br>
<a href="rbac_privileges_has_actions_view.php">privileges has actions</a><br>
<a href="rbac_actions_view.php">actions</a><br>
<br>
<b>Domains</b><br>
<a href="rbac_domains_view.php">domains</a><br>
<a href="rbac_domains_has_objects_view.php">domains has objects</a><br>
<a href="rbac_objects_view.php">objects</a><br>