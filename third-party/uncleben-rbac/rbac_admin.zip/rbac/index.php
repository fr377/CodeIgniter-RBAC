<?php

header('Location: cp/users_view.php');
